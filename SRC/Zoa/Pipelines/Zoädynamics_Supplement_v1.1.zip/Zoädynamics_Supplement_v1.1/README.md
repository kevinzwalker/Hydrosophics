# Zoädynamics Fantasia v1.0 – Supplemental Code

This repository provides the **reproducible analysis pipeline** used in:

> Walker, K. Z. (2025). *Zoädynamics: A Physiological Coherence Framework And Pilot Validation On The Fantasia Dataset.* PsyArXiv. https://doi.org/10.31234/osf.io/mtsnx_v2

The goal of this package is to let collaborators and teaching labs
re-run the core analyses from the preprint on the PhysioNet Fantasia
dataset with minimal setup.

---

## Contents

- `code/`
  - `Fantasia_v1_configured_experimental.py` – main processing script (single subject).
  - `run_fantasia_batch.py` – helper script for looping over multiple subjects.
- `config/`
  - `fantasia_v1_config.yml` – analysis configuration (channels, windows, outputs).
  - `environment.yml` – Conda environment specification.
- `metadata/`
  - `fantasia_v1_batch.json` – subject list and cohort labels.
  - `fantasia_v1_metadata.json` – package and provenance metadata.
- `results_verify/`
  - Example outputs used to generate Figures 1–2 in the preprint.

---

## Setup

1. Install Anaconda or Miniconda.
2. From this folder, create the environment:

   conda env create -f config/environment.yml
   conda activate Zoadynamics_fantasia_v1


Verify installation by running:
	- python code/Fantasia_v1_configured_experimental.py --help

##Running the pipeline
#Single subject
	- python code/Fantasia_v1_configured_experimental.py \
  --config config/fantasia_v1_config.yml \
  --subject f2y07

This will:

-load the selected Fantasia record from PhysioNet,

-compute the Hydrosophic Master Equation observables (C, D, ΔE),

-write CSV outputs to results/,

-and produce 30-min HME plots for the chosen subject.

#Batch mode (all subjects in manifest)
	- python code/run_fantasia_batch.py \
  --config config/fantasia_v1_config.yml \
  --batch metadata/fantasia_v1_batch.json

Progress and any per-subject issues are logged to the console.

##Data access

*The pipeline expects local copies of the Fantasia dataset:

Goldberger et al. (2000). PhysioBank, PhysioToolkit, and PhysioNet:
Components of a new research resource for complex physiologic
signals. Circulation, 101(23), e215–e220.
Dataset DOI: https://doi.org/10.13026/C2RG61

*Update the data_root field in config/fantasia_v1_config.yml to point to
your local Fantasia directory.

##Citation

If you use this code or adapt the pipeline, please cite:

Walker, K. (2025). Zoädynamics: A Physiological Coherence Framework And Pilot Validation On The Fantasia Dataset. PsyArXiv. https://doi.org/10.31234/osf.io/mtsnx_v2

Hello there:)

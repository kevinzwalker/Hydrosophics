# Reproducibility Statement

This supplemental package provides all code, configurations, metadata, and environment specifications required to fully reproduce the analyses reported in:

**Walker, K. (2025). *Zoädynamics: A Physiological Coherence Framework And Pilot Validation On The Fantasia Dataset*. PsyArXiv. [https://doi.org/10.31234/osf.io/mtsnx_v2](https://doi.org/10.31234/osf.io/mtsnx_v2)**

## Included Materials

This repository contains:

* **Full analysis scripts** (`Fantasia_v1_configured_experimental.py`, `run_fantasia_batch.py`)
* **Configuration files** (`fantasia_v1_config.yml`, `fantasia_v1_batch.json`)
* **Conda environment specification** (`environment.yml`)
* **Metadata** (`fantasia_v1_metadata.json`)
* **Example outputs** (`results_verify/`)
* **Citation file** (`CITATION.cff`)
* **License** (CC-BY 4.0 International)

All files are versioned and aligned with the preprint’s analyses.

## Environment Reproduction

Install the environment with:

```bash
conda env create -f config/environment.yml
conda activate Zoaydynamics_fantasia_v1
```

This ensures all dependencies (Python, NumPy, Pandas, WFDB, SciPy, Matplotlib, NeuroKit2, PyYAML) match the original working versions used in the preprint.

## Pipeline Execution

### Single Subject

```bash
python code/Fantasia_v1_configured_experimental.py \
    --config config/fantasia_v1_config.yml \
    --subject f2y07
```

### Batch Mode

```bash
python code/run_fantasia_batch.py \
    --config config/fantasia_v1_config.yml \
    --batch metadata/fantasia_v1_batch.json
```

These scripts fully reconstruct all tables, observables, and Hydrosophic Master Equation (HME) plots exactly as used in the preprint.

## Data Access

The analyses require local copies of the **PhysioNet Fantasia** dataset:

Goldberger et al. (2000). *Components of a new research resource for complex physiologic signals.*
Circulation, 101(23), e215–e220.
Dataset DOI: [https://doi.org/10.13026/C2RG61](https://doi.org/10.13026/C2RG61)

Update the `data_root` field in `fantasia_v1_config.yml` to point to your local directory.

## Determinism and Known Variability

* All random operations are avoided or fixed by design.
* Observables (C, D, ΔE) are deterministic given the input signal.
* Minor floating-point differences may arise across CPU architectures.
* Plot appearance may vary slightly depending on backend, but numerical values will match.

## Contact

For collaboration inquiries, clarification, or suggestions, please contact:

**Kevin Zachary Walker**
Author
OSF Preprint: [https://doi.org/10.31234/osf.io/mtsnx_v2](https://doi.org/10.31234/osf.io/mtsnx_v2)




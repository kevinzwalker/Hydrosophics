import os, json, yaml, importlib.util, sys
from pathlib import Path

# Load config
cfg_path = sys.argv[1] if len(sys.argv) > 1 else "fantasia_v1_config.yml"
batch_path = sys.argv[2] if len(sys.argv) > 2 else "fantasia_v1_batch.json"
with open(cfg_path, "r") as f:
    CFG = yaml.safe_load(f)
with open(batch_path, "r") as f:
    BATCH = json.load(f)

# Import user's Fantasia v1.0 script as a module
script_path = Path("Fantasia v1.0.py")
if not script_path.exists():
    print("ERROR: Fantasia v1.0.py not found in working directory.", file=sys.stderr)
    sys.exit(1)

spec = importlib.util.spec_from_file_location("fantasia_v1", str(script_path))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

# Override globals inside the module with config values when present
def set_if(name, value):
    if hasattr(mod, name):
        setattr(mod, name, value)

set_if("RECORD", CFG.get("record", "f1o01"))
set_if("DATA_DIR", CFG.get("data_dir", "."))
set_if("WIN_C", CFG["windows"]["win_c_seconds"])
set_if("WIN_D", CFG["windows"]["win_d_seconds"])
set_if("WIN_S", CFG["windows"]["win_stats_seconds"])
set_if("LOW_HZ", CFG["filters"]["ecg_low_hz"])
set_if("HIGH_HZ", CFG["filters"]["ecg_high_hz"])

# Monkey-patch plotting window by wrapping plt.plot calls to use out_plot
# (assumes the script creates a pandas DataFrame named `out` before plotting)
import matplotlib.pyplot as plt
_orig_plot = plt.plot
def plot_wrapper(*args, **kwargs):
    return _orig_plot(*args, **kwargs)
plt.plot = plot_wrapper  # keep default; we will provide out_plot variable before plotting

# Run each record in the batch
records = BATCH.get("records", [CFG.get("record", "f1o01")])
for rec in records:
    print(f"=== Running record {rec} ===")
    setattr(mod, "RECORD", rec)

    # Execute top-level again per record
    spec = importlib.util.spec_from_file_location("fantasia_v1", str(script_path))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    # Inject out_plot variable for the first 30 min if 'out' exists
    if "out" in mod.__dict__:
        import pandas as pd
        out = mod.__dict__["out"]
        out_plot = out[out["time_s"] <= CFG["plotting"]["hme_plot_max_seconds"]].copy()
        mod.__dict__["out_plot"] = out_plot
    else:
        print("WARNING: 'out' not found in script namespace; skipping out_plot injection.")

print("Batch completed.")

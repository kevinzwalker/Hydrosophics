# Fantasia_v1.py
import os, numpy as np, pandas as pd, matplotlib.pyplot as plt
import wfdb, neurokit2 as nk
from scipy.signal import butter, filtfilt

# ---------- CONFIG ----------
RECORD   = "f2o07"    # e.g., f1o01, f1y01, f2o05 ...
DATA_DIR = "."        # folder containing the .hea/.dat
WIN_C = 7.0
WIN_D = 5.0
WIN_S    = 10.0       # seconds for time-anchored rolling stats
LOW_HZ, HIGH_HZ = 0.5, 25.0
OUT_PREFIX = f"results_{RECORD}"
EPS = 1e-8

# ---------- HELPERS ----------
def clamp01(x): 
    return np.clip(x, 0.0, 1.0)

def bandpass(sig, fs, low=0.5, high=25.0, order=4):
    """Butterworth bandpass."""
    b, a = butter(order, [low/(fs/2), high/(fs/2)], btype="band")
    return filtfilt(b, a, sig)

def smooth(x, win=5):
    s = pd.Series(np.asarray(x, float)).rolling(
        win, min_periods=max(1, win//2), center=True
    ).mean().ffill().bfill()
    return s.to_numpy()

def minmax01(x, lo=None, hi=None):
    x = np.asarray(x, float)
    lo = np.nanmin(x) if lo is None else lo
    hi = np.nanmax(x) if hi is None else hi
    return np.clip((x - lo) / (hi - lo + EPS), 0.0, 1.0), (lo, hi)

def ecg_preprocess(raw, fs, low=LOW_HZ, high=HIGH_HZ):
    """Bandpass + clean + robust z-normalize."""
    sig = bandpass(raw, fs, low=low, high=high)
    sig = nk.ecg_clean(sig, sampling_rate=fs, method="biosppy")
    sig = (sig - np.median(sig)) / (np.std(sig) + EPS)
    return sig

def pick_rpeaks(x, fs):
    b,a = butter(4, [0.5, 25.0], btype='band', fs=fs)  # stricter high-cut for F2
    x = filtfilt(b,a,x)
    for m in ["hamilton2002","christov2004","pantompkins1985",None]:
        try:
            if m is None:
                _, info = nk.ecg_process(x, sampling_rate=fs)
                r = np.asarray(info["ECG_R_Peaks"], int)
                used = "nk_process"
            else:
                _, d = nk.ecg_peaks(x, sampling_rate=fs, method=m)
                r = np.asarray(d["ECG_R_Peaks"], int)
                used = m
            if r.size >= 50:
                rr = np.diff(r)/fs
                med = np.median(60.0/(rr+1e-8))
                if 30 <= med <= 200:
                    iqr = np.subtract(*np.percentile(60.0/(rr+1e-8), [75,25]))
                    return r, used, med, iqr
        except Exception:
            pass
    raise RuntimeError("No valid R-peak detection found.")


def compute_rmssd_series(rr_ms, hr_bpm, win_s=WIN_S):
    """Time-anchored RMSSD over ~win_s seconds (per beat)."""
    rr_ms = np.asarray(rr_ms, float)
    hr    = smooth(np.asarray(hr_bpm, float), win=5)
    bps   = np.clip(hr/60.0, 12/60.0, 180/60.0)                # beats/sec
    win_beats = np.maximum(5, (win_s * bps).astype(int))

    vals = np.full_like(rr_ms, np.nan, float)
    for i in range(len(rr_ms)):
        w = int(win_beats[i]); start = max(0, i - w + 1)
        seg = rr_ms[start:i+1]
        if seg.size >= 5:
            d = np.diff(seg)
            vals[i] = np.sqrt(np.mean(d*d))
    return pd.Series(vals)

# ---------- LOAD ----------
record_path = os.path.join(DATA_DIR, RECORD)
hdr = wfdb.rdheader(record_path)
rec = wfdb.rdrecord(record_path, channels=None)
fs = rec.fs
print("Channels:", rec.sig_name)  # ['RESP','ECG','BP']

# Map by NAME (use 'ECG', not 'ECG1')
ch = rec.sig_name
resp_sig = rec.p_signal[:, ch.index('RESP')].astype(float)
ecg_sig  = rec.p_signal[:, ch.index('ECG') ].astype(float)
if 'BP' in ch:
    bp_sig   = rec.p_signal[:, ch.index('BP')  ].astype(float)
else:
    bp_sig = None

# Fill NaNs + robust normalize ECG
t = np.arange(ecg_sig.size)
m = np.isfinite(ecg_sig)
if not m.all():
    ecg_sig = np.interp(t, t[m], ecg_sig[m])
ecg_sig = (ecg_sig - np.median(ecg_sig)) / (np.std(ecg_sig) + 1e-8)
ecg_raw = ecg_sig  # keep old var name for downstream

# ---------- PREPROCESS & R-PEAKS ----------
sig = ecg_preprocess(ecg_raw, fs, low=LOW_HZ, high=HIGH_HZ)  # 0.5–40
sig_fs = fs

rpeaks, det_used, hr_med, hr_iqr = pick_rpeaks(sig, sig_fs)


# ---------- RR / HR ----------
rr_s   = np.diff(rpeaks) / sig_fs
rr_ms  = rr_s * 1000.0
hr_inst = 60.0 / (rr_s + EPS)
hr_t   = rpeaks[1:] / sig_fs

# -------- ΔE from BP when present (beat-aligned) -------
DeltaE = None
DeltaE_beats = None
if bp_sig is not None:
    bp_z   = (bp_sig - np.mean(bp_sig)) / (np.std(bp_sig) + EPS)
    dP     = np.abs(np.gradient(bp_z))
    k      = max(3, int(0.5 * fs))  # ~0.5 s smoothing
    dP_sm  = pd.Series(dP).rolling(k, center=True, min_periods=1).mean().to_numpy()
    scale  = np.percentile(dP_sm, 95)
    mech   = np.clip(dP_sm / (scale + EPS), 0, 1)

    # aggregate mechanical energy per beat interval
    DeltaE_beats = np.full(len(rpeaks) - 1, np.nan)
    for i in range(1, len(rpeaks)):
        s = rpeaks[i-1]; e = rpeaks[i]
        if e > s + 1:
            DeltaE_beats[i-1] = np.nanmean(mech[s:e])
    # light smoothing on beat domain
    DeltaE = pd.Series(DeltaE_beats).rolling(3, center=True, min_periods=1).mean().to_numpy()

# --- Hydrosophic HR cleaning (Fly06+) ---
import pandas as pd

# Beat-by-beat series indexed by beat time (sec)
_hr = pd.Series(hr_inst, index=pd.Index(hr_t, name="t"))

# Fill short gaps from occasional missed beats
_hr = _hr.interpolate(limit=2)  # only bridges very short gaps

# Suppress spikes with a small rolling median (3 beats)
_hr = _hr.rolling(window=3, center=True, min_periods=1).median()

# Back to numpy arrays for downstream code
hr_inst = _hr.to_numpy()

# ---------- HME OBSERVABLES ----------
# 1) Coherence C from RMSSD (~WIN_S sec), anchored to 10–150 ms
rmssd_series = compute_rmssd_series(rr_ms, hr_inst, win_s=WIN_C)
C, _ = minmax01(rmssd_series.values, lo=10.0, hi=100.0)

# 2) Dephasing D from local HR volatility (MAD over ~WIN_S sec), 0–3 bpm
hr = smooth(hr_inst, win=5)
bps = np.clip(hr/60.0, 12/60.0, 180/60.0)
win_beats = np.maximum(5, (WIN_D * bps).astype(int))
hr_mad = np.full_like(hr, np.nan, float)
for i in range(len(hr)):
    w = int(win_beats[i]); start = max(0, i - w + 1)
    seg = hr[start:i+1]
    if seg.size >= 5:
        m = np.median(seg)
        hr_mad[i] = np.median(np.abs(seg - m))
D, _ = minmax01(np.clip(hr_mad, 0, 2.5), lo=0.0, hi=2.5)

# 3) Energetic drag ΔE as 1 − C (placeholder for LF/HF later)
if DeltaE_beats is not None:
    DeltaE = DeltaE_beats[:len(C)]
else:
    DeltaE = 1.0 - C

# Align vectors (defensive)
n = min(len(hr_t), len(rr_ms), len(rmssd_series), len(C), len(D), len(DeltaE))
out = pd.DataFrame({
    "time_s":   hr_t[:n],
    "HR_bpm":   hr_inst[:n],
    "RR_ms":    rr_ms[:n],
    "RMSSD_ms": rmssd_series.values[:n],
    "C":        C[:n],
    "D":        D[:n],
    "DeltaE":   DeltaE[:n],
    "detector": [det_used]*n
}).dropna().reset_index(drop=True)

# ---------- SAVE ----------
os.makedirs("results", exist_ok=True)
csv_path = os.path.join("results", f"{OUT_PREFIX}.csv")
out.to_csv(csv_path, index=False)

# ---------- PLOTS ----------
# zoomed ECG (10 s window around mid-record)
mid = len(sig) // 2
span = int(10 * fs) // 2
lo, hi = max(0, mid - span), min(len(sig), mid + span)
t_zoom = np.arange(lo, hi) / fs
plt.figure(figsize=(10,3))
plt.plot(t_zoom, sig[lo:hi], lw=0.9)
rz = rpeaks[(rpeaks >= lo) & (rpeaks < hi)]
plt.scatter(rz/fs, sig[rz], s=12)
plt.title(f"{RECORD} ECG (10 s zoom)")
plt.xlabel("Time (s)"); plt.ylabel("ECG (z)")
plt.tight_layout(); plt.savefig(os.path.join("results", f"{OUT_PREFIX}_ecg_zoom.png")); plt.close()

plt.figure(figsize=(10,3))
plt.plot(out["time_s"], out["HR_bpm"], lw=1)
plt.title("Instantaneous HR")
plt.xlabel("Time (s)"); plt.ylabel("bpm")
plt.tight_layout(); plt.savefig(os.path.join("results", f"{OUT_PREFIX}_hr.png")); plt.close()

# ---- Optional: restrict to first 30 minutes for plotting ----
MAX_T = 30 * 60  # 30 minutes in seconds
mask = out["time_s"] <= MAX_T
out_plot = out[mask].reset_index(drop=True)

plt.figure(figsize=(10,5))
plt.subplot(3,1,1); plt.plot(out_plot["time_s"], out_plot["C"]); plt.ylim(0,1); plt.ylabel("C")
plt.subplot(3,1,2); plt.plot(out_plot["time_s"], out_plot["D"]); plt.ylim(0,1); plt.ylabel("D")
plt.subplot(3,1,3); plt.plot(out_plot["time_s"], out_plot["DeltaE"]); plt.ylim(0,1); plt.ylabel("ΔE"); plt.xlabel("Time (s)")
plt.suptitle("HME observables from Fantasia (first 30 min)")
plt.tight_layout(rect=[0,0,1,0.95])
plt.savefig(os.path.join("results", f"{OUT_PREFIX}_hme.png")); plt.close()

print(f"Saved: {csv_path} | detector={det_used} | median_HR={hr_med:.1f} bpm")
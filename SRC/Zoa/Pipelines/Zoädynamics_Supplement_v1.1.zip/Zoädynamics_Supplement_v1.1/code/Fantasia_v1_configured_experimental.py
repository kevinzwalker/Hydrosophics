
# Fantasia_v1.0_configured.py
# Config-driven version of the Hydrosophics Fantasia v1.0 baseline pipeline.
# Reads YAML config, enforces 30-min plotting (or as configured), and saves outputs under results/.

import os, sys, yaml
import numpy as np, pandas as pd
import matplotlib.pyplot as plt
import wfdb, neurokit2 as nk
from scipy.signal import butter, filtfilt

# ------------------ CONFIG LOADING ------------------
CFG_PATH = sys.argv[1] if len(sys.argv) > 1 else "fantasia_v1_config.yml"
with open(CFG_PATH, "r") as f:
    CFG = yaml.safe_load(f)

RECORD   = CFG.get("record", "f1o01")
DATA_DIR = CFG.get("data_dir", ".")
WIN_C    = CFG.get("windows", {}).get("win_c_seconds", 7.0)
WIN_D    = CFG.get("windows", {}).get("win_d_seconds", 5.0)
WIN_S    = CFG.get("windows", {}).get("win_stats_seconds", 10.0)
LOW_HZ   = CFG.get("filters", {}).get("ecg_low_hz", 0.5)
HIGH_HZ  = CFG.get("filters", {}).get("ecg_high_hz", 25.0)
EPS      = CFG.get("eps", 1e-8)

NORM_RMSSD_MIN = CFG.get("normalization", {}).get("rmssd_min_ms", 10.0)
NORM_RMSSD_MAX = CFG.get("normalization", {}).get("rmssd_max_ms", 100.0)
NORM_HRMAD_MIN = CFG.get("normalization", {}).get("hr_mad_min_bpm", 0.0)
NORM_HRMAD_MAX = CFG.get("normalization", {}).get("hr_mad_max_bpm", 2.5)

USE_BP   = CFG.get("bp_mechanical_energy", {}).get("use_bp_if_available", True)
SMOOTH_S = CFG.get("bp_mechanical_energy", {}).get("smooth_seconds", 0.5)
PCT_SCL  = CFG.get("bp_mechanical_energy", {}).get("percentile_scale", 95)

PLOT_MAX = CFG.get("plotting", {}).get("hme_plot_max_seconds", 1800)
ECG_ZOOM_SEC = CFG.get("plotting", {}).get("ecg_zoom_seconds", 10)

CH_ECG   = CFG.get("channels", {}).get("ecg", "ECG")
CH_RESP  = CFG.get("channels", {}).get("resp", "RESP")
CH_BP    = CFG.get("channels", {}).get("bp_optional", "BP")

OUT_DIR  = CFG.get("output", {}).get("out_dir", "results")
OUT_PREF = CFG.get("output", {}).get("out_prefix_template", "results_{record}").format(record=RECORD)

DETECTORS = CFG.get("detectors", ["hamilton2002","christov2004","pantompkins1985","nk_process"])

os.makedirs(OUT_DIR, exist_ok=True)

# ------------------ HELPERS ------------------
def clamp01(x): 
    return np.clip(x, 0.0, 1.0)

def bandpass(sig, fs, low=0.5, high=25.0, order=4):
    b, a = butter(order, [low/(fs/2), high/(fs/2)], btype="band")
    return filtfilt(b, a, sig)

def smooth(x, win=5):
    s = pd.Series(np.asarray(x, float)).rolling(
        win, min_periods=max(1, win//2), center=True
    ).mean().ffill().bfill()
    return s.to_numpy()

def minmax01(x, lo=None, hi=None, eps=1e-8):
    x = np.asarray(x, float)
    lo = np.nanmin(x) if lo is None else lo
    hi = np.nanmax(x) if hi is None else hi
    return np.clip((x - lo) / (hi - lo + eps), 0.0, 1.0), (lo, hi)

def ecg_preprocess(raw, fs, low=0.5, high=25.0):
    sig = bandpass(raw, fs, low=low, high=high)
    sig = nk.ecg_clean(sig, sampling_rate=fs, method="biosppy")
    sig = (sig - np.median(sig)) / (np.std(sig) + 1e-8)
    return sig

def pick_rpeaks(x, fs, detectors):
    # Slight stricter high-cut for robustness (like original)
    b,a = butter(4, [0.5, 25.0], btype='band', fs=fs)
    x = filtfilt(b,a,x)
    for m in detectors + [None]:
        try:
            if m is None:
                _, info = nk.ecg_process(x, sampling_rate=fs)
                r = np.asarray(info["ECG_R_Peaks"], int)
                used = "nk_process"
            else:
                _, d = nk.ecg_peaks(x, sampling_rate=fs, method=m)
                r = np.asarray(d["ECG_R_Peaks"], int)
                used = m
            if r.size >= 50:
                rr = np.diff(r)/fs
                med = np.median(60.0/(rr+1e-8))
                if 30 <= med <= 200:
                    iqr = np.subtract(*np.percentile(60.0/(rr+1e-8), [75,25]))
                    return r, used, med, iqr
        except Exception:
            pass
    raise RuntimeError("No valid R-peak detection found.")

# ------------------ LOAD ------------------
record_path = os.path.join(DATA_DIR, RECORD)
hdr = wfdb.rdheader(record_path)
rec = wfdb.rdrecord(record_path, channels=None)
fs = rec.fs
ch = rec.sig_name

# Pull channels
resp_sig = rec.p_signal[:, ch.index(CH_RESP)].astype(float) if CH_RESP in ch else None
ecg_sig  = rec.p_signal[:, ch.index(CH_ECG) ].astype(float) if CH_ECG in ch else None
bp_sig   = rec.p_signal[:, ch.index(CH_BP)  ].astype(float) if (CH_BP in ch and USE_BP) else None

if ecg_sig is None:
    raise RuntimeError(f"ECG channel '{CH_ECG}' not found in record {RECORD}. Available: {ch}")

# Fill NaNs + robust normalize ECG
t = np.arange(ecg_sig.size)
m = np.isfinite(ecg_sig)
if not m.all():
    ecg_sig = np.interp(t, t[m], ecg_sig[m])
ecg_raw = (ecg_sig - np.median(ecg_sig)) / (np.std(ecg_sig) + 1e-8)

# ------------------ PREPROCESS & R-PEAKS ------------------
sig = ecg_preprocess(ecg_raw, fs, low=LOW_HZ, high=HIGH_HZ)
rpeaks, det_used, hr_med, hr_iqr = pick_rpeaks(sig, fs, DETECTORS)

# ------------------ RR / HR ------------------
rr_s   = np.diff(rpeaks) / fs
rr_ms  = rr_s * 1000.0
hr_inst = 60.0 / (rr_s + 1e-8)
hr_t   = rpeaks[1:] / fs

# -------- ΔE from BP when present (beat-aligned) -------
DeltaE = None
DeltaE_beats = None
if bp_sig is not None:
    bp_z   = (bp_sig - np.mean(bp_sig)) / (np.std(bp_sig) + 1e-8)
    dP     = np.abs(np.gradient(bp_z))
    k      = max(3, int(SMOOTH_S * fs))  # smoothing window
    dP_sm  = pd.Series(dP).rolling(k, center=True, min_periods=1).mean().to_numpy()
    scale  = np.percentile(dP_sm, PCT_SCL)
    mech   = np.clip(dP_sm / (scale + 1e-8), 0, 1)

    DeltaE_beats = np.full(len(rpeaks) - 1, np.nan)
    for i in range(1, len(rpeaks)):
        s = rpeaks[i-1]; e = rpeaks[i]
        if e > s + 1:
            DeltaE_beats[i-1] = np.nanmean(mech[s:e])
    DeltaE = pd.Series(DeltaE_beats).rolling(3, center=True, min_periods=1).mean().to_numpy()

# --- Hydrosophic HR cleaning ---
_hr = pd.Series(hr_inst, index=pd.Index(hr_t, name="t"))
_hr = _hr.interpolate(limit=2).rolling(window=3, center=True, min_periods=1).median()
hr_inst = _hr.to_numpy()

# ------------------ HME OBSERVABLES ------------------
def compute_rmssd_series(rr_ms, hr_bpm, win_s=10.0):
    rr_ms = np.asarray(rr_ms, float)
    hr    = smooth(np.asarray(hr_bpm, float), win=5)
    bps   = np.clip(hr/60.0, 12/60.0, 180/60.0)
    win_beats = np.maximum(5, (win_s * bps).astype(int))

    vals = np.full_like(rr_ms, np.nan, float)
    for i in range(len(rr_ms)):
        w = int(win_beats[i]); start = max(0, i - w + 1)
        seg = rr_ms[start:i+1]
        if seg.size >= 5:
            d = np.diff(seg)
            vals[i] = np.sqrt(np.mean(d*d))
    return pd.Series(vals)

rmssd_series = compute_rmssd_series(rr_ms, hr_inst, win_s=WIN_C)
C, _ = minmax01(rmssd_series.values, lo=NORM_RMSSD_MIN, hi=NORM_RMSSD_MAX)

hr = smooth(hr_inst, win=5)
bps = np.clip(hr/60.0, 12/60.0, 180/60.0)
win_beats = np.maximum(5, (WIN_D * bps).astype(int))
hr_mad = np.full_like(hr, np.nan, float)
for i in range(len(hr)):
    w = int(win_beats[i]); start = max(0, i - w + 1)
    seg = hr[start:i+1]
    if seg.size >= 5:
        m = np.median(seg)
        hr_mad[i] = np.median(np.abs(seg - m))
D, _ = minmax01(np.clip(hr_mad, NORM_HRMAD_MIN, NORM_HRMAD_MAX), lo=NORM_HRMAD_MIN, hi=NORM_HRMAD_MAX)

if DeltaE_beats is not None:
    DeltaE = DeltaE_beats[:len(C)]
else:
    DeltaE = 1.0 - C

# ------------------ ALIGN & SAVE ------------------
n = min(len(hr_t), len(rr_ms), len(rmssd_series), len(C), len(D), len(DeltaE))
out = pd.DataFrame({
    "time_s":   hr_t[:n],
    "HR_bpm":   hr_inst[:n],
    "RR_ms":    rr_ms[:n],
    "RMSSD_ms": rmssd_series.values[:n],
    "C":        C[:n],
    "D":        D[:n],
    "DeltaE":   DeltaE[:n],
    "detector": [det_used]*n
}).dropna().reset_index(drop=True)

csv_path = os.path.join(OUT_DIR, f"{OUT_PREF}.csv")
out.to_csv(csv_path, index=False)

# ------------------ PLOTS (FIRST N SECONDS) ------------------
out_plot = out[out["time_s"] <= float(PLOT_MAX)].copy()

# ECG zoom (10 s around mid-record of filtered ECG)
mid = len(sig) // 2
span = int(ECG_ZOOM_SEC * fs) // 2
lo, hi = max(0, mid - span), min(len(sig), mid + span)
t_zoom = np.arange(lo, hi) / fs
plt.figure(figsize=(10,3))
plt.plot(t_zoom, sig[lo:hi], lw=0.9)
rz = np.array([])
try:
    rpeaks_arr = np.array(rpeaks)
    rz = rpeaks_arr[(rpeaks_arr >= lo) & (rpeaks_arr < hi)]
    plt.scatter(rz/fs, sig[rz], s=12)
except Exception:
    pass
plt.title(f"{RECORD} ECG (10 s zoom)")
plt.xlabel("Time (s)"); plt.ylabel("ECG (z)")
plt.tight_layout(); plt.savefig(os.path.join(OUT_DIR, f"{OUT_PREF}_ecg_zoom.png")); plt.close()

# HR
plt.figure(figsize=(10,3))
plt.plot(out_plot["time_s"], out_plot["HR_bpm"], lw=1)
plt.title("Instantaneous HR (first {:.0f} min)".format(PLOT_MAX/60.0))
plt.xlabel("Time (s)"); plt.ylabel("bpm")
plt.tight_layout(); plt.savefig(os.path.join(OUT_DIR, f"{OUT_PREF}_hr.png")); plt.close()

# HME (styled)
plt.figure(figsize=(10,5))
plt.subplot(3,1,1)
plt.plot(out_plot['time_s'], out_plot['C'])
plt.ylim(0,1)
plt.ylabel('C')
plt.subplot(3,1,2)
plt.plot(out_plot['time_s'], out_plot['D'])
plt.ylim(0,1)
plt.ylabel('D')
plt.subplot(3,1,3)
plt.plot(out_plot['time_s'], out_plot['DeltaE'])
plt.ylim(0,1)
plt.ylabel('ΔE')
plt.xlabel('Time (s)')
plt.suptitle('HME observables from Fantasia')
plt.tight_layout(rect=[0,0,1,0.95])
plt.savefig(os.path.join(OUT_DIR, f"{OUT_PREF}_hme.png"))
plt.close()

print(f"Saved: {csv_path} | detector={det_used}")
